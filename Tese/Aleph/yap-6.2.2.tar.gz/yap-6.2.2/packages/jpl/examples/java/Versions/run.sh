#!/bin/sh

. ../env.sh

run Versions

