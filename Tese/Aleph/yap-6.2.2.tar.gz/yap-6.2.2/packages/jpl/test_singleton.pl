% serves testSingleton1() in jpl.test.TestJUnit

t(A).

