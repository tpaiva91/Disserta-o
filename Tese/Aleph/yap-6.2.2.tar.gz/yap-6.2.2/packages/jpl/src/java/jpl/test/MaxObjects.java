package jpl.test;

public class MaxObjects {
}
