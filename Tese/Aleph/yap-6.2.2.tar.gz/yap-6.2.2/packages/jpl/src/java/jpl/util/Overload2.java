package jpl.util;

public class Overload2
	{
	// experiment (why not read the language reference?)
	public static int fred;
	public static int fred()
		{
		return fred;
		}
	}


